# frozen_string_literal: true

Test = Struct.new(:name, :date, :description)
