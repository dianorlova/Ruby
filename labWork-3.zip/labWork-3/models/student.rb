# frozen_string_literal: true

Student = Struct.new(:surname, :name, :patronymic, :date, :sex)
