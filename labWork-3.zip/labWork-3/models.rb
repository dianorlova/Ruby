# frozen_string_literal: true

require_relative 'models/student'
require_relative 'models/schools'
